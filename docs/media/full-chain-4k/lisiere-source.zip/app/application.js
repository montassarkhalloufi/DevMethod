(function (root, factory) {
  const api = factory(root.LisiereDomain);
  if (typeof module === "object" && module.exports) module.exports = factory(require("./domain.js"));
  root.LisiereApplication = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (Domain) {
  "use strict";

  function create(options) {
    const storage = options.storage;
    const idFactory = options.idFactory;
    let state = { books: [], filter: "all", warning: null, incompatible: false, persistenceSafe: false };

    function snapshot() {
      const { persistenceSafe: _, ...publicState } = state;
      return { ...publicState, books: state.books.map((book) => ({ ...book })) };
    }
    function persist() {
      if (!state.persistenceSafe) return { ok: false, kind: state.incompatible ? "incompatible" : "read" };
      const result = storage.save(state.books);
      state.warning = result.ok ? null : "write";
      return result;
    }
    function initialize() {
      const result = storage.load();
      if (result.ok) { state.books = result.books; state.persistenceSafe = true; }
      else { state.warning = result.kind; state.incompatible = result.kind === "incompatible"; }
      return snapshot();
    }
    function add(input) {
      const result = Domain.createBook(input, idFactory);
      if (!result.ok) return result;
      state.books = [result.book, ...state.books];
      state.filter = "all";
      persist();
      return { ok: true, book: { ...result.book }, state: snapshot() };
    }
    function transition(id) {
      const index = state.books.findIndex((book) => book.id === id);
      if (index < 0) return { ok: false, error: "not-found" };
      const result = Domain.transitionBook(state.books[index]);
      if (!result.ok) return result;
      state.books = state.books.map((book, position) => position === index ? result.book : book);
      persist();
      return { ok: true, book: { ...result.book }, state: snapshot() };
    }
    function setFilter(filter) {
      const result = Domain.filterBooks(state.books, filter);
      if (!result.ok) return result;
      state.filter = filter;
      return { ok: true, books: result.books, state: snapshot() };
    }
    function visibleBooks() { return Domain.filterBooks(state.books, state.filter).books; }
    function retry() { persist(); return snapshot(); }
    function reset() {
      const result = storage.reset();
      if (!result.ok) { state.warning = "delete"; return { ok: false, state: snapshot() }; }
      state = { books: [], filter: "all", warning: null, incompatible: false, persistenceSafe: true };
      return { ok: true, state: snapshot() };
    }
    return { initialize, add, transition, setFilter, visibleBooks, retry, reset, snapshot };
  }
  return { create };
});
