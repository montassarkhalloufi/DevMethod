const test = require("node:test");
const assert = require("node:assert/strict");
const D = require("../app/domain.js");

const ID = "123e4567-e89b-42d3-a456-426614174000";

test("normalise les bords sans altérer les espaces intérieurs", () => {
  assert.deepEqual(D.normalizeField("  Le  livre  "), { ok: true, value: "Le  livre" });
  assert.deepEqual(D.normalizeField(" \n "), { ok: false, error: "required" });
});

test("compte les points de code Unicode et applique la limite de 120", () => {
  assert.equal(D.codePointLength("📚"), 1);
  assert.equal(D.normalizeField("é".repeat(120)).ok, true);
  assert.deepEqual(D.normalizeField("📚".repeat(121)), { ok: false, error: "too-long" });
});

test("crée un UUID v4 sans randomUUID", () => {
  const cryptoPort = { getRandomValues(bytes) { bytes.fill(17); return bytes; } };
  assert.equal(D.createUuid(cryptoPort), "11111111-1111-4111-9111-111111111111");
  assert.match(D.createUuid({}, () => 0), /^[0-9a-f-]{36}$/);
});

test("associe seulement les trois titres et auteurs approuvés aux crops", () => {
  assert.equal(D.referenceCover({ title: "Les jours tranquilles", author: "Élise Martin" }), "jours");
  assert.equal(D.referenceCover({ title: "Atlas des chemins", author: "Autre" }), null);
});

test("crée un livre planned normalisé et refuse chaque champ invalide", () => {
  assert.deepEqual(D.createBook({ title: "  Lisière ", author: "  A. Test " }, () => ID), {
    ok: true, book: { id: ID, title: "Lisière", author: "A. Test", status: "planned" }
  });
  assert.deepEqual(D.createBook({ title: " ", author: "x".repeat(121) }, () => ID).errors, { title: "required", author: "too-long" });
});

test("applique uniquement le cycle planned → reading → done → reading", () => {
  let book = { id: ID, title: "Titre", author: "Auteur", status: "planned" };
  for (const expected of ["reading", "done", "reading"]) {
    const result = D.transitionBook(book); assert.equal(result.ok, true); assert.equal(result.book.status, expected); book = result.book;
  }
  assert.deepEqual(D.transitionBook({ ...book, status: "other" }), { ok: false, error: "invalid-book" });
});

test("filtre sans muter ni réordonner", () => {
  const books = [
    { id: ID, title: "A", author: "A", status: "planned" },
    { id: "223e4567-e89b-42d3-a456-426614174001", title: "B", author: "B", status: "reading" }
  ];
  assert.deepEqual(D.filterBooks(books, "reading").books.map((b) => b.title), ["B"]);
  assert.notEqual(D.filterBooks(books, "all").books, books);
  assert.deepEqual(D.filterBooks(books, "unknown"), { ok: false, error: "invalid-filter" });
});

test("produit une graine de couverture stable et sensible aux données", () => {
  const book = { id: ID, title: "A", author: "B", status: "planned" };
  assert.equal(D.coverSeed(book), D.coverSeed({ ...book }));
  assert.notEqual(D.coverSeed(book), D.coverSeed({ ...book, title: "C" }));
});
