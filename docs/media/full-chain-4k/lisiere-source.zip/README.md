# Lisière — source de la démonstration

Node.js22+ : `node --test tests/*.test.js`. Depuis la racine extraite, `python3 -m http.server 8767`, puis ouvrir http://localhost:8767/app/.

Vérifications navigateur : Playwright et Chrome installés, PLAYWRIGHT_MODULE si nécessaire. Créer /private/tmp/devmethod-film4k pour les captures, puis exécuter les scripts verification/*.cjs. Ces scripts utilisent un contexte navigateur neuf et des données fictives.

La mission conserve les preuves historiques et leurs limites; les chemins temporaires mentionnés décrivent le tournage original.
