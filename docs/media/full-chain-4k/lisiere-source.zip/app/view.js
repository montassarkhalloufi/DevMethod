(function () {
  "use strict";
  const D = window.LisiereDomain;
  const storage = window.LisiereStorage.fromBrowser(window);
  const app = window.LisiereApplication.create({ storage, idFactory: () => D.createUuid(window.crypto) });
  const library = document.querySelector("#library");
  const statusRegion = document.querySelector("#results-status");
  const warning = document.querySelector("#storage-warning");
  const dialog = document.querySelector("#book-dialog");
  const form = document.querySelector("#book-form");
  let returnFocus = null;

  const labels = {
    planned: { status: "À lire", action: "Commencer" },
    reading: { status: "En cours", action: "Marquer terminé" },
    done: { status: "Terminé", action: "Rouvrir" }
  };

  function coverStyle(book) {
    const seed = D.coverSeed(book);
    const palettes = [
      ["#efe4d0", "#c98b63", "#65735b"], ["#b94327", "#e1b879", "#283944"],
      ["#cbd9dc", "#698a9c", "#263e52"], ["#d7c9ac", "#875f46", "#35483f"]
    ];
    const palette = palettes[seed % palettes.length];
    return `--cover-a:${palette[0]};--cover-b:${palette[1]};--cover-c:${palette[2]};--cover-shift:${seed % 37}%`;
  }

  function coverMarkup(book) {
    const reference = D.referenceCover(book);
    if (reference) return `<div class="cover cover-reference cover-${reference}" aria-hidden="true"></div>`;
    return `<div class="cover" aria-hidden="true" style="${coverStyle(book)}"><span>${escapeText(book.title)}</span><small>${escapeText(book.author)}</small></div>`;
  }

  function escapeText(value) {
    const node = document.createElement("span"); node.textContent = value; return node.innerHTML;
  }

  function renderWarning(state) {
    if (!state.warning) { warning.hidden = true; warning.replaceChildren(); return; }
    warning.hidden = false;
    if (state.incompatible) {
      warning.innerHTML = `<div><strong>Données locales illisibles</strong><p>La bibliothèque enregistrée n’a pas été chargée.</p></div><button type="button" data-warning-action="reset">Réinitialiser les données locales</button>`;
    } else if (state.warning === "read") {
      warning.innerHTML = `<div><strong>Stockage local indisponible</strong><p>La bibliothèque enregistrée n’a pas pu être lue. Aucun changement local n’a été effectué.</p></div><button type="button" data-warning-action="reload">Réessayer de charger</button>`;
    } else {
      warning.innerHTML = `<div><strong>Stockage local indisponible</strong><p>Vos changements restent visibles, mais ne seront peut-être pas conservés.</p></div><button type="button" data-warning-action="retry">Réessayer d’enregistrer</button>`;
    }
  }

  function render(options = {}) {
    const state = app.snapshot();
    const books = app.visibleBooks();
    document.querySelectorAll("[data-filter]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.filter === state.filter)));
    renderWarning(state);
    if (!books.length) {
      const filtered = state.books.length > 0;
      library.className = "library empty-state";
      library.innerHTML = filtered
        ? `<h2>Aucun livre dans cette catégorie</h2><p>Explorez toute votre bibliothèque pour poursuivre.</p><button class="button" type="button" data-empty-action="all">Voir tous les livres</button>`
        : `<h2>Votre bibliothèque est vide</h2><p>Ajoutez votre premier livre pour commencer votre suivi.</p><button class="button button-primary open-dialog" type="button">Ajouter votre premier livre</button>`;
    } else {
      library.className = "library";
      library.innerHTML = books.map((book) => `<article class="book" data-id="${book.id}">
        ${coverMarkup(book)}
        <div class="book-info"><h2 tabindex="-1">${escapeText(book.title)}</h2><p>${escapeText(book.author)}</p><span class="badge badge-${book.status}">${labels[book.status].status}</span>
        <button class="button book-action" type="button" data-book-action="${book.id}">${labels[book.status].action}</button></div></article>`).join("");
    }
    if (options.announce) statusRegion.textContent = `${books.length} ${books.length > 1 ? "livres affichés" : "livre affiché"}.`;
    if (options.focusBook) library.querySelector(`[data-id="${options.focusBook}"] h2`)?.focus();
  }

  function openDialog(trigger) {
    returnFocus = trigger;
    clearErrors();
    dialog.showModal();
    document.querySelector("#title").focus();
  }
  function closeDialog() { dialog.close(); returnFocus?.focus(); }
  function clearErrors() {
    for (const name of ["title", "author"]) {
      const input = form.elements[name]; input.removeAttribute("aria-invalid");
      document.querySelector(`#${name}-error`).textContent = "";
    }
    document.querySelector("#form-error").textContent = "";
  }
  function showErrors(errors) {
    const messages = { required: "Ce champ est requis.", "too-long": "120 caractères maximum." };
    let first;
    for (const name of ["title", "author"]) if (errors[name]) {
      const input = form.elements[name]; input.setAttribute("aria-invalid", "true");
      document.querySelector(`#${name}-error`).textContent = messages[errors[name]] || "Valeur invalide.";
      first ||= input;
    }
    first?.focus();
    if (errors.form) {
      document.querySelector("#form-error").textContent = "Impossible de créer un identifiant local. Réessayez.";
      document.querySelector("#form-error").focus();
    }
  }

  document.addEventListener("click", (event) => {
    const open = event.target.closest(".open-dialog"); if (open) return openDialog(open);
    if (event.target.closest(".close-dialog")) return closeDialog();
    const filter = event.target.closest("[data-filter]");
    if (filter) { app.setFilter(filter.dataset.filter); return render({ announce: true }); }
    const action = event.target.closest("[data-book-action]");
    if (action) { const id = action.dataset.bookAction; app.transition(id); render(); library.querySelector(`[data-book-action="${id}"]`)?.focus(); return; }
    const empty = event.target.closest("[data-empty-action='all']");
    if (empty) { app.setFilter("all"); render({ announce: true }); document.querySelector("[data-filter='all']").focus(); return; }
    const warningAction = event.target.closest("[data-warning-action]");
    if (warningAction?.dataset.warningAction === "retry") { app.retry(); render(); }
    if (warningAction?.dataset.warningAction === "reload") { window.location.reload(); }
    if (warningAction?.dataset.warningAction === "reset" && window.confirm("Réinitialiser uniquement les données locales de Lisière ? Cette action est irréversible.")) { app.reset(); render(); }
  });
  form.addEventListener("submit", (event) => {
    event.preventDefault(); clearErrors();
    const result = app.add({ title: form.elements.title.value, author: form.elements.author.value });
    if (!result.ok) return showErrors(result.errors);
    form.reset(); dialog.close(); render({ announce: true, focusBook: result.book.id });
  });
  dialog.addEventListener("cancel", (event) => { event.preventDefault(); closeDialog(); });
  dialog.addEventListener("close", () => { if (document.activeElement === document.body) returnFocus?.focus(); });

  app.initialize();
  render();
})();
