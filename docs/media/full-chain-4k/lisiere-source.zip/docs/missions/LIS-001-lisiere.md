# Mission LIS-001 — Lisière

## État de la mission

- Étape accomplie : integrate LISIERE-1 — prototype livré localement, vérification finale09b acceptée avec limites documentées.
- Statut produit : périmètre, contrat UX et frontières de l’implémentation statique arrêtés à partir du brief et de la référence approuvée.
- Statut de livraison : application statique et preuves locales intégrées; livraison limitée aux fichiers locaux, sans dépôt Git, fusion, PR, publication ni déploiement.
- Prochaine action canonique : `$project-foundation next LISIERE-1`.

## Résultat recherché

Créer, à partir de zéro, un petit outil personnel de suivi de lectures en français. Une personne doit pouvoir constituer une bibliothèque fictive, voir immédiatement où en est chaque livre et faire évoluer son statut sans compte, réseau ni service tiers.

Le succès attendu est une expérience locale, simple et fiable, qui fonctionne directement dans le navigateur et respecte la direction éditoriale déjà approuvée sur ordinateur comme sur mobile.

## Besoin exploré

### Utilisateur et situation

- Utilisateur principal : une personne qui suit sa propre liste de lectures sur un appareil et dans un navigateur donnés.
- Problème : mémoriser les livres prévus, en cours ou terminés et mettre leur état à jour avec très peu d'effort.
- Moment d'usage : consultation rapide de la bibliothèque, ajout d'un titre, démarrage ou achèvement d'une lecture, reprise d'un livre terminé.
- Valeur centrale : une vue lisible et calme de « ce que je veux lire, ce que je lis et ce que j'ai fini », sans inscription ni configuration.

### Parcours indispensables issus du brief

1. Ajouter un livre fictif avec un titre et un auteur.
2. Consulter tous les livres ou filtrer par statut : à lire, en cours, terminés.
3. Commencer un livre prévu, terminer un livre en cours et rouvrir un livre terminé.
4. Retrouver les données après rechargement grâce au stockage local du navigateur.
5. Comprendre clairement une panne ou une indisponibilité de ce stockage.
6. Comprendre une bibliothèque ou un filtre sans résultat grâce à un état vide utile.
7. Effectuer les actions essentielles au clavier.

### Hypothèse de proposition de valeur

Lisière se distingue ici par une combinaison volontairement resserrée : suivi individuel, interactions directes, absence de compte et atmosphère de bibliothèque éditoriale. Ce n'est pas un catalogue, un réseau social de lecteurs ni un outil d'analyse de lecture.

## Périmètre autorisé

### Plus petite version utile

Une page locale permet de saisir un titre et un auteur, puis de suivre chaque livre dans un cycle unique : **À lire → En cours → Terminé → En cours**. La bibliothèque est vide au premier lancement; les livres du mockup restent des exemples visuels, pas des données imposées. Un ajout commence à **À lire**. Les doublons sont acceptés, car aucune identité bibliographique n'est disponible. Les valeurs composées uniquement d'espaces sont refusées. L'ordre retenu est l'ajout le plus récent en premier et ne change pas avec le statut.

### Inclus

- Une application locale statique en HTML, CSS et JavaScript natifs.
- Des livres fictifs uniquement.
- Les données minimales `titre`, `auteur` et `statut` nécessaires aux parcours décrits.
- Les filtres Tous / À lire / En cours / Terminés.
- Les transitions commencer / terminer / rouvrir.
- La persistance dans `localStorage`, avec avertissement visible en cas d'échec.
- Un état vide et l'usage au clavier.
- Une adaptation responsive de la référence approuvée.

### Exclus

- Backend, compte, synchronisation entre appareils ou appels à un fournisseur.
- Contenu de lecture ou extraits de livres.
- Messages externes, achats et déploiement.
- Génération de nouvelles images dans cette mission.
- Reprise d'une ancienne implémentation : seule la référence visuelle approuvée est réutilisable.
- Développement pendant les étapes d'exploration et de cadrage.
- Modification, suppression, recherche, tri configurable, notes, progression, dates et statistiques.

## Direction produit et visuelle acceptée

- Direction retenue : **A — Éditorial**, ivoire / encre / rouille, décrite comme une bibliothèque personnelle « comme un livre bien écrit ».
- Référence maîtresse : [`references/editorial-mockup-v1.png`](../../references/editorial-mockup-v1.png), 1536 × 1024, SHA-256 `f6cd5677f25db809c05deeb703efdfcb8ccc9e6df24d5d5acc7295dffc1384e3`.
- Historique des directions : [`references/directions-v1.png`](../../references/directions-v1.png), 1536 × 1024. Ce fichier prouve le choix entre A, B et C mais ne concurrence pas l'écran maître.
- La référence montre une grille de cartes sur desktop et une liste compacte sur mobile, avec typographie sérif, séparateurs fins, accents rouille, statuts doux et actions explicites.
- La géométrie exacte peut s'adapter au viewport à condition que les écarts soient signalés lors de la vérification.
- Les recadrages de couvertures peuvent être obtenus par positionnement CSS d'arrière-plan.

## Contrat de conception

### Réutilisation approuvée et niveau d'autorité

Cette conception réutilise explicitement le choix **A — Éditorial** et l'écran maître `editorial-mockup-v1.png`, tous deux approuvés par le même utilisateur lors de la session de préparation. Aucune nouvelle direction ni fausse image n'est créée. Le master fait autorité sur la hiérarchie, la densité, la composition et le ton; les comportements absents ci-dessous sont des décisions réversibles nécessaires au MVP, pas des éléments prétendument visibles dans l'image.

### Tokens à préserver

- **Couleurs sémantiques :** fond ivoire chaud, surface papier légèrement plus claire, encre presque noire, texte secondaire gris brun, accent/action rouille foncé, filet gris chaud; statuts en pastilles douces avec texte explicite — pêche pour « À lire », vert sauge pour « En cours », rouille pâle pour « Terminé ».
- **Typographie :** famille sérif éditoriale disponible localement; contraste par taille, graisse et italique, sans police distante. Titre de page très ample sur desktop et fortement réduit sur mobile; texte courant confortable, métadonnées plus petites mais lisibles.
- **Espacement :** rythme de base de 8 px; paliers 8 / 16 / 24 / 32 / 48 / 64 px. Conteneur centré et respirant; alignements nets entre en-tête, filtres, cartes et pied.
- **Forme :** rayons discrets (environ 4 px) pour boutons, champs et pastilles; filets fins de 1 px; ombres légères réservées aux couvertures et aux surfaces superposées. Aucun effet brillant ni décoration ajoutée.
- **Interaction :** accent rouille pour action principale, bord rouille pour action de carte; focus de 2 px minimum, contrasté et décalé, visible sur tous les contrôles. Les états ne reposent jamais uniquement sur la couleur.
- **Média :** proportions verticales cohérentes pour les couvertures; les trois couvertures du master sont une référence visuelle, pas des données initiales. Une couverture abstraite et déterministe peut être composée sans appel réseau lors d'un ajout; aucun contenu éditorial réel n'est suggéré.

### Écran maître et composants

L'ordre vertical est verrouillé : en-tête « Lisière / Bibliothèque personnelle » avec filet; bloc titre et promesse avec CTA « Ajouter un livre »; barre de quatre filtres; bibliothèque; pied avec maxime et mention « Démonstration · Livres fictifs ». Sur desktop, la bibliothèque est une grille de trois colonnes : couverture, titre, auteur, pastille de statut puis action pleine largeur. Les libellés métier sont « Commencer », « Marquer terminé » et « Rouvrir » selon le cycle accepté. Le filtre actif est rouille et souligné; les autres restent textuels.

L'ajout ouvre un panneau de dialogue centré, nommé « Ajouter un livre », avec champs « Titre » et « Auteur », action principale « Ajouter » et action « Annuler ». Le focus entre sur le titre, reste contenu dans le dialogue, `Échap` annule, et la fermeture rend le focus au CTA. La validation conserve les saisies et affiche sous chaque champ vide ou composé d'espaces un message lié au champ. Un succès ferme le dialogue, insère le livre en tête, active « Tous » et place le focus sur le titre de la nouvelle carte.

### Responsive

- **Large (≥ 1024 px) :** conteneur maximal voisin de 1000 px, hero sur deux zones, grille trois colonnes et pied sur une ligne, conformément au panneau desktop du master.
- **Intermédiaire (640–1023 px) :** marges de 24–32 px, hero conservé si l'espace le permet, grille deux colonnes; c'est une interpolation documentée, absente du master.
- **Étroit (< 640 px) :** marges de 16 px, en-tête compact, titre/promesse puis CTA pleine largeur; filtres sur une ligne défilable horizontalement si nécessaire, sans couper les libellés. Chaque livre devient une ligne : vignette à gauche, informations et action à droite; pied empilé, comme le panneau mobile approuvé.
- Aucun débordement horizontal de page; le texte long se replie sans recouvrir statut ou action. À 200 % de zoom, les commandes restent accessibles et l'ordre de lecture demeure celui du document.

### États et interactions nécessaires

- Filtres et actions sont des boutons natifs, activables avec `Entrée` et `Espace`; l'actif expose son état sélectionné. Le changement de filtre ne déplace pas le focus et annonce le nombre de résultats dans une région de statut discrète.
- Bibliothèque vide : « Votre bibliothèque est vide » et CTA « Ajouter votre premier livre ». Filtre vide : « Aucun livre dans cette catégorie » et action « Voir tous les livres »; aucune donnée fictive n'est injectée.
- Pendant une écriture locale, l'interface peut être mise à jour immédiatement. En cas d'échec, un avertissement persistant en haut du contenu indique que les changements ne seront pas conservés; le livre reste disponible en mémoire pour la session et « Réessayer d'enregistrer » est proposé.
- Données absentes : bibliothèque vide normale. Données illisibles, de forme invalide ou de version inconnue : elles ne sont pas interprétées; avertissement persistant et action « Réinitialiser les données locales », précédée d'une confirmation explicite. Aucun succès factice.
- Le dialogue expose ses erreurs au clavier et aux technologies d'assistance; l'avertissement de stockage est annoncé sans voler le focus. Le mouvement est évité ou neutralisé selon la préférence de réduction des animations.

### Matrice UX minimale

| Parcours | État initial | Résultat / récupération |
|---|---|---|
| Ajouter | Dialogue vide ou saisie conservée après erreur | Livre « À lire » en tête; erreur de champ locale et corrigeable |
| Filtrer | Tous actif | Sous-ensemble annoncé; état vide avec retour vers Tous |
| Changer le statut | Carte focalisée | Libellé, pastille et action suivants mis à jour; focus conservé |
| Charger / conserver | Données locales valides | Bibliothèque restaurée; avertissement et session mémoire sinon |
| Réinitialiser des données invalides | Avertissement persistant | Confirmation puis bibliothèque vide; annulation sans perte |

Il n'existe pas d'état de chargement réseau, de droits insuffisants ni de données distantes périmées dans cette application locale.

## Contraintes et frontières

- Zéro dépendance applicative, gestionnaire de paquets, backend ou appel réseau.
- Surface : application privée locale, interactive, rendue statiquement par le navigateur.
- Données détenues : bibliothèque fictive locale au navigateur. Aucune donnée personnelle requise par le besoin connu.
- Persistance : `localStorage`; sa panne ne doit ni être silencieuse ni rendre l'interface incompréhensible.
- Accessibilité attendue : parcours clavier des commandes essentielles, libellés et états perceptibles autrement que par la seule couleur.
- Le parent de la session garde la responsabilité de la génération d'images et de la vérification réelle dans le navigateur.
- Aucun budget, délai ou permission de publication/déploiement n'est défini.

## Architecture retenue

### Frontières minimales et dépendances

L’application reste un ensemble de fichiers statiques ouvrable directement dans un navigateur, sans compilation, module distant ni serveur. Quatre responsabilités suffisent; elles ne justifient ni framework, ni dépôt générique, ni couche supplémentaire :

1. **Domaine pur** : valide et normalise les champs, crée un livre, applique le cycle de statut, filtre la collection et produit la graine visuelle déterministe. Il ne lit ni le DOM ni `localStorage` et expose des fonctions testables par entrées/sorties.
2. **Stockage local** : seul adaptateur autorisé autour de `localStorage`; il sérialise, charge et valide l’enveloppe persistée. Il traduit toute exception ou donnée incompatible en résultats explicites, sans modifier le domaine.
3. **Application et vue** : détient l’état en mémoire de la session, orchestre les cas d’usage, rend le DOM et gère dialogue, focus, annonces et avertissements. Elle dépend du domaine et du contrat de stockage; aucune règle de statut ou validation persistée ne vit dans le rendu.
4. **Composition** : initialise l’application, fournit l’adaptateur navigateur et branche les événements. Elle ne contient aucune règle métier.

Pour préserver l’ouverture en `file://`, les scripts sont classiques et chargés dans un ordre explicite; chaque frontière expose un espace de noms unique, sans variable métier globale mutable. Le domaine demeure compatible avec un chargement isolé par un futur harnais de test. Une séparation plus fine ne sera introduite que si une responsabilité devient impossible à tester isolément.

### Contrat du domaine

- Un livre en mémoire est `{ id, title, author, status }`; `status` appartient strictement à `planned | reading | done`.
- `title` et `author` sont des chaînes dont les espaces extérieurs sont retirés, non vides, limitées chacune à 120 points de code Unicode. Les espaces intérieurs sont conservés. La vue peut aider avec `maxlength`, mais le domaine garantit seul l’invariant.
- `id` est un UUID généré à la création; un identifiant déjà présent ou invalide rend une donnée chargée incompatible. Les doublons titre/auteur restent permis.
- La collection est ordonnée du plus récent ajout au plus ancien par sa position dans le tableau; aucune date n’est nécessaire. Une transition de statut ne réordonne pas la collection.
- Les seules transitions valides sont `planned → reading`, `reading → done` et `done → reading`. Toute autre valeur ou transition produit une erreur stable, sans mutation partielle.
- La couverture abstraite est dérivée par une fonction de hachage simple et stable de `id`, `title` et `author`, puis mappée vers une palette et une position CSS locales. Elle n’est ni stockée ni chargée depuis le réseau.

### Contrat de stockage et récupération

- Clé possédée : `lisiere.library`; valeur JSON : `{ "version": 1, "books": [...] }`. Aucune autre clé navigateur n’est lue ou modifiée.
- Une clé absente signifie une bibliothèque vide. JSON illisible, enveloppe non conforme, version inconnue, livre invalide ou identifiant dupliqué rendent l’ensemble incompatible : aucune récupération partielle ni réécriture silencieuse.
- L’état en mémoire est la source immédiate de la session. Après chaque ajout ou transition, l’application tente d’enregistrer un instantané complet. Un échec conserve cet état en mémoire, affiche l’avertissement prévu et permet de réessayer le même instantané.
- La réinitialisation d’une valeur incompatible requiert la confirmation prévue, puis supprime uniquement `lisiere.library`; si cette suppression échoue, l’avertissement persiste et aucun succès n’est annoncé.
- Il n’existe ni transaction multi-clé, ni migration avant une éventuelle version 2. Une future évolution devra lire explicitement la version 1 et produire une nouvelle enveloppe sans écraser une donnée non reconnue.
- L’usage simultané dans plusieurs onglets n’appartient pas au MVP : le dernier instantané écrit gagne. Ce choix devra être revu si la synchronisation intra-navigateur devient un besoin.

### Compatibilité, erreurs et vérification attendue

La cible est la version stable courante de Chrome, Edge, Firefox et Safari au moment de la vérification, avec JavaScript activé et les capacités `localStorage`, `crypto.randomUUID` et `<dialog>`. Aucun polyfill n’est autorisé. L’absence d’une capacité requise produit un avertissement explicite et maintient autant que possible la consultation en mémoire; le support d’un navigateur ancien imposerait de reconsidérer ce choix.

Les tests unitaires devront couvrir les fonctions pures (normalisation, limites Unicode, transitions, filtres, graine) et l’adaptateur de stockage avec un faux port (absence, lecture valide, JSON/schéma/version invalides, doublon d’identifiant, exceptions de lecture/écriture/suppression). Les tests d’orchestration devront vérifier que l’état mémoire survit à un échec d’écriture et que les erreurs deviennent les états UX prévus. Le choix du harnais sans dépendance sera arrêté au plan après inspection des runtimes réellement disponibles. La vérification navigateur desktop/mobile, clavier, zoom, contraste, `file://` et défaillances simulées reste sous la responsabilité du parent.

## Critères observables à conserver lors du cadrage

- **C1 — Ajout :** un titre et un auteur valides permettent de créer un livre et de le voir dans la bibliothèque.
- **C2 — Filtrage :** chaque filtre n'affiche que les livres du statut attendu; Tous les rassemble.
- **C3 — Cycle :** un livre peut passer de À lire à En cours, de En cours à Terminé, puis être rouvert en En cours.
- **C4 — Persistance :** un rechargement conserve la bibliothèque lorsque `localStorage` fonctionne.
- **C5 — Défaillance locale :** un échec de lecture ou d'écriture du stockage produit un avertissement compréhensible.
- **C6 — Absence de résultat :** une bibliothèque vide et un filtre vide ont un rendu explicite.
- **C7 — Clavier :** ajout, filtres et changements de statut sont utilisables sans souris.
- **C8 — Fidélité :** desktop et mobile préservent la hiérarchie, le ton et les composants essentiels de l'écran maître approuvé.
- **C9 — Autonomie :** l'application ne requiert ni dépendance, ni backend, ni appel fournisseur pour fonctionner.

Ces critères viennent du brief; leurs cas limites et preuves détaillées appartiennent aux prochaines étapes.

## Inconnues et décisions restantes

- Aucun blocage d’architecture n’est connu pour planifier le MVP.
- Le harnais de test exact dépend des runtimes locaux qui seront constatés au plan; il ne peut ajouter aucune dépendance applicative.
- Mesures finales de contraste et écarts géométriques aux viewports de référence, à relever uniquement lors de la vérification réelle par le parent.

## Critères de réussite du MVP

La mission réussit lorsque C1 à C9 disposent chacun d'une preuve reliée à l'implémentation concernée. Fonctionnellement, une personne peut ajouter un livre valide, parcourir sans ambiguïté le cycle défini, filtrer les quatre vues et retrouver sa bibliothèque après rechargement. Une panne de stockage et les deux formes d'absence de résultat restent compréhensibles. Les commandes essentielles sont atteignables et activables au clavier, avec focus visible et état non communiqué par la seule couleur. L'écran conserve sur desktop et mobile la hiérarchie éditoriale de la référence maîtresse sans exiger une géométrie identique. L'application fonctionne hors réseau, sans dépendance ni service tiers.

La preuve de fidélité et des parcours dans un navigateur réel appartient au parent; une inspection de fichiers ne suffira pas à déclarer la mission réussie.

## Risques principaux

- Interpréter le mockup comme une spécification complète et inventer silencieusement les états absents.
- Perdre des données ou masquer une erreur lorsque `localStorage` refuse une opération ou contient une valeur invalide.
- Reproduire l'apparence tout en négligeant focus, sémantique HTML, contrastes ou navigation clavier.
- Rendre l'adaptation mobile trop dense ou rompre la hiérarchie éditoriale en cherchant une géométrie pixel-perfect.
- Élargir le produit vers la gestion complète d'une bibliothèque alors que le besoin est un suivi minimal.

## Sources et autorité

| Source inspectée | Autorité par sujet | État |
|---|---|---|
| [`BRIEF.md`](../../BRIEF.md), SHA-256 `c25811f93eb01acdee6d88c85fc46d9fe597dc34e67c63c6dda7becfc4e2e98e` | Besoin, contraintes, exclusions, validation antérieure de la direction A | Source de vérité fournie |
| [`references/editorial-mockup-v1.png`](../../references/editorial-mockup-v1.png) | Composition, style et adaptation desktop/mobile | Référence visuelle approuvée |
| [`references/directions-v1.png`](../../references/directions-v1.png) | Historique comparatif des trois directions | Contexte; A seule est retenue |
| [`PROJECT_PROFILE.md`](../../PROJECT_PROFILE.md) | Aucun fait produit : gabarit d'installation encore vierge | Non canonique |
| [`START_HERE.md`](../../START_HERE.md) et `AGENTS.foundation.md` | Mode opératoire du kit | Instructions de méthode, pas décisions produit |

`CONTRIBUTING.md` et `AGENTS.md` sont absents. Aucun manifeste, lockfile, code applicatif, commande projet, dépôt Git ou CI n'existe à ce stade.

## Responsabilités et preuves futures

- Cette mission est l'unique registre canonique de contexte, de plan et de preuves tant que sa taille ne justifie pas une séparation.
- Le parent effectuera la vérification réelle dans le navigateur; elle ne peut pas être revendiquée ici.
- Une future implémentation devra relier chaque preuve aux critères C1–C9 et distinguer inspection locale, revue et vérification navigateur.
- Toute publication ou tout déploiement demandera une autorisation distincte.

## Condition de sortie de l'exploration

L'exploration est terminée : utilisateur, problème, valeur, parcours, limites, référence approuvée, risques et inconnues sont identifiés à partir des sources disponibles. Aucun code ni test applicatif n'a été créé ou exécuté.

## Condition de sortie du cadrage

Le cadrage est terminé : la plus petite version utile, son cycle de statut, son état initial, son ordre stable, ses exclusions et ses critères de réussite sont explicites. À cette sortie d'étape, les décisions d'interface, de gestion des données invalides et de compatibilité navigateur restaient à traiter. Aucun code ni test applicatif n'avait été créé ou exécuté.

## Condition de sortie de la conception

La conception est terminée : les tokens, l'écran maître, l'ajout, la validation, les états vides et de stockage, le focus, le clavier et les adaptations large, intermédiaire et mobile sont formalisés. Elle réutilise la direction A et le master approuvés sans nouvelle image ni code. Les limites de champ, le schéma de stockage et les navigateurs cibles restent à décider à l'architecture. La fidélité réelle n'est pas vérifiée dans un navigateur à ce stade.

## Condition de sortie de l’architecture

L’architecture est terminée : domaine pur, stockage local, application/vue et composition ont des responsabilités et dépendances explicites. Les invariants du livre, le cycle, les limites Unicode, la version 1 du stockage, les comportements d’échec, la génération locale des couvertures et la cible navigateur sont arrêtés. Ces choix restent proportionnés à une page ouverte en `file://`, sans dépendance ni code à ce stade. Le harnais de test sera choisi au plan d’après les runtimes constatés; la vérification réelle dans le navigateur reste réservée au parent.

## Plan — première tranche LISIERE-1

**Objectif.** Livrer le MVP local complet sous forme de fichiers HTML/CSS/JS classiques ouvrables en `file://` : ajout, filtres, cycle des statuts, persistance et récupération explicite, états vides, clavier et adaptation fidèle à la référence approuvée.

**Périmètre et exclusions.** LISIERE-1 couvre exactement C1 à C9 et les quatre frontières arrêtées. Les livres exemples ne sont pas préchargés. Restent exclus backend, réseau, dépendances, compte, contenu réel, fonctions de gestion supplémentaires, nouvelle image et déploiement.

**Critères d’acceptation.** (1) Une saisie normalisée valide crée en tête un livre `planned`; les champs vides/espaces ou dépassant 120 points de code restent corrigeables. (2) Tous / À lire / En cours / Terminés filtrent correctement et annoncent leur résultat. (3) Le cycle unique `planned → reading → done → reading` conserve ordre et focus. (4) Une enveloppe v1 valide survit au rechargement. (5) lecture, écriture ou suppression en échec, ainsi que donnée incompatible, produisent l’avertissement et la récupération prévus sans succès factice. (6) Les deux états vides offrent l’action attendue. (7) dialogue, ajout, filtres et statuts sont utilisables au clavier avec focus visible. (8) desktop, intermédiaire et mobile préservent hiérarchie, composants et ton éditorial approuvés, sans débordement. (9) l’application fonctionne hors réseau et sans dépendance.

**Dépendances et ordre.** Aucun blocage connu. Node.js `v24.18.0` est disponible localement; aucun manifeste, paquet, code ou CI n’existe. Implémenter domaine pur → adaptateur de stockage injecté → application/vue et accessibilité → composition/styles responsive. Respecter `lisiere.library`, l’enveloppe v1, les espaces de noms uniques et la référence `editorial-mockup-v1.png`. Le parent reste seul responsable de la vérification navigateur réelle.

**Tests et preuve attendue.** Utiliser le module natif `node:test`, sans installation : tests unitaires du domaine (normalisation Unicode, limites, transitions, filtres, graine) et du stockage avec faux port (absence, valeur valide, JSON/schéma/version/ID invalides, exceptions lire/écrire/supprimer), puis tests d’orchestration sur survie en mémoire et états d’erreur. Preuves Codex : fichiers/diff, commande exacte et sortie des tests, inspection de l’absence de dépendance/appel réseau et matrice C1–C9 reliant code et contrôles. Preuves réservées au parent : ouverture `file://`, parcours desktop/mobile et clavier, rechargement, zoom 200 %, contraste, défaillances simulées et écarts visuels documentés face au master. Aucun de ces contrôles n’est déclaré réussi au plan.

**Définition de terminé.** Code revu, tests sans dépendance réussis et preuves Codex reliées à C1–C9; la mission ne sera déclarée totalement réussie qu’après ajout des preuves navigateur du parent.

## Condition de sortie du plan

LISIERE-1 est la première tranche cohérente et bornée; ses critères, dépendances, contrôles et propriétaires de preuve sont explicites. Aucun code ni test applicatif n’a été créé ou exécuté pendant ce plan.

## Reprise exacte

Exécuter `$project-foundation next LISIERE-1` pour constater la clôture locale de cette tranche et sélectionner une éventuelle suite explicitement autorisée, sans démarrer de nouveau périmètre par défaut.

## Preuves d’implémentation — LISIERE-1 — 2026-09-13

- C1–C3 : `app/domain.js`, `app/application.js` et `app/view.js` couvrent validation, ajout en tête, filtres et cycle stable; tests dédiés dans `tests/domain.test.js` et `tests/application.test.js`.
- C4–C5 : `app/storage.js` possède uniquement `lisiere.library`, valide strictement l’enveloppe v1 et traduit les échecs; récupération et survie mémoire testées dans `tests/storage.test.js` et `tests/application.test.js`.
- C6–C8 : `app/index.html`, `app/view.js` et `app/styles.css` implémentent les deux états vides, le dialogue, les annonces, le focus visible et les compositions trois/deux/une colonne. Leur validation visuelle et interactive réelle reste à faire dans Chrome par le parent.
- C9 : inspection locale de `app/` sans URL, appel réseau, import distant, manifeste ni dépendance applicative.
- Commande exécutée après corrections : `node --test tests/*.test.js` — 27 tests réussis, 0 échec. `node --check` a aussi réussi sur tous les fichiers JavaScript de `app/` et `tests/`; la recherche statique n’a trouvé aucun appel ou import réseau.
- Corrections de revue : après lecture échouée ou données incompatibles, ajout et retry restent en mémoire sans aucun `setItem`; seule une réinitialisation confirmée et réussie réautorise la persistance. L’accès au getter `localStorage` est capturé par `Storage.fromBrowser`. `crypto.randomUUID` possède un repli UUID v4 (`getRandomValues`, puis source locale de dernier recours). La limite de 120 est imposée en points de code par le domaine, sans `maxlength` UTF-16 contradictoire.
- Fidélité média : les couples titre/auteur des trois ouvrages du master sélectionnent des crops CSS de `references/editorial-mockup-v1.png`; tous les autres livres conservent leur couverture abstraite déterministe.
- Régressions ajoutées : verrou de persistance après échec de lecture/incompatibilité, réautorisation après reset, getter `localStorage` levant, UUID sans `randomUUID`, limite astrale Unicode et sélection stricte des trois crops.
- Limite de preuve : aucune ouverture navigateur, capture, mesure de contraste ou comparaison de rendu n’a été effectuée dans cette étape.

## Intégration locale — LISIERE-1 — 2026-09-13

- La vérification finale09b a accepté le prototype local. La preuve canonique associée est [`BROWSER-EVIDENCE.md`](../../BROWSER-EVIDENCE.md), qui remplace l’échec préliminaire pour la régression du getter `localStorage`.
- Sont observés dans Chrome via Playwright : parcours normal desktop, ajout et cycle des statuts, filtres et état vide, persistance après rechargement, avertissements de stockage, fermeture du dialogue, repli UUID, limite Unicode, parcours intégral au clavier et absence de débordement aux largeurs contrôlées.
- Les ratios de contraste relevés sur les paires CSS sélectionnées dépassent 4,5. Les captures desktop et mobile ont été inspectées contre la référence approuvée avec les adaptations documentées de typographie, d’espacement, de couvertures et de taille des boutons.
- Limites acceptées : aucune identité pixel, aucune métrique perceptuelle automatisée, aucun panel humain séparé, aucun audit complet d’accessibilité ou inter-navigateurs. Le reflow à 720 et 320 px ne prouve pas un zoom Chrome natif à 200 %, qui reste non vérifié.
- Mode de livraison réel : prototype enregistré localement seulement. Le dossier n’étant pas un dépôt Git, aucune fusion, PR, publication ou mise en production n’existe ni n’est revendiquée.
- LISIERE-1 est close dans ce mode de livraison et dans ces limites. Toute suite fonctionnelle, publication ou validation supplémentaire constitue une nouvelle autorisation.
