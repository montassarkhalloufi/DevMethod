import path from 'node:path';
import { pathToFileURL } from 'node:url';
const [root, file, command, id, payload] = process.argv.slice(2);
const { createStore } = await import(pathToFileURL(path.join(root, 'src/store.mjs')));
const { validateBody } = await import(pathToFileURL(path.join(root, 'src/domain.mjs')));
const store = createStore(file);
const result = command === 'list' ? await store.list() : await store.update(id, validateBody(JSON.parse(payload), true));
console.log(JSON.stringify(result));
