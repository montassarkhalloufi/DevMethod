const test = require("node:test");
const assert = require("node:assert/strict");
const App = require("../app/application.js");
const IDS = ["123e4567-e89b-42d3-a456-426614174000", "223e4567-e89b-42d3-a456-426614174001"];

function harness(overrides = {}) {
  let index = 0;
  const storage = {
    load: () => ({ ok: true, books: [] }), save: () => ({ ok: true }), reset: () => ({ ok: true }), ...overrides
  };
  return App.create({ storage, idFactory: () => IDS[index++] });
}

test("ajoute en tête, repasse sur Tous et garde l’ordre après transition", () => {
  const app = harness(); app.initialize();
  app.add({ title: "Premier", author: "A" }); app.setFilter("planned");
  app.add({ title: "Second", author: "B" });
  assert.deepEqual(app.snapshot().books.map((b) => b.title), ["Second", "Premier"]);
  assert.equal(app.snapshot().filter, "all");
  app.transition(IDS[1]);
  assert.deepEqual(app.snapshot().books.map((b) => b.title), ["Second", "Premier"]);
  assert.equal(app.snapshot().books[0].status, "reading");
});

test("conserve l’état mémoire et signale un échec d’écriture", () => {
  const app = harness({ save: () => ({ ok: false, kind: "write" }) }); app.initialize();
  const result = app.add({ title: "Mémoire", author: "Locale" });
  assert.equal(result.ok, true); assert.equal(app.snapshot().books.length, 1); assert.equal(app.snapshot().warning, "write");
});

test("réessayer retire l’avertissement seulement après succès", () => {
  let succeeds = false;
  const app = harness({ save: () => succeeds ? { ok: true } : { ok: false, kind: "write" } }); app.initialize();
  app.add({ title: "A", author: "B" }); assert.equal(app.snapshot().warning, "write");
  succeeds = true; app.retry(); assert.equal(app.snapshot().warning, null);
});

test("une donnée incompatible devient un état récupérable sans livres", () => {
  const app = harness({ load: () => ({ ok: false, kind: "incompatible" }) });
  assert.deepEqual(app.initialize(), { books: [], filter: "all", warning: "incompatible", incompatible: true });
});

test("un échec de lecture reste distinct d’un échec d’écriture", () => {
  const app = harness({ load: () => ({ ok: false, kind: "read" }) });
  assert.equal(app.initialize().warning, "read");
  assert.equal(app.snapshot().incompatible, false);
});

test("ajout et retry n’écrasent jamais une bibliothèque non chargée", () => {
  let saves = 0;
  const app = harness({ load: () => ({ ok: false, kind: "read" }), save: () => { saves += 1; return { ok: true }; } });
  app.initialize();
  assert.equal(app.add({ title: "Session", author: "Mémoire" }).ok, true);
  app.retry();
  assert.equal(saves, 0);
  assert.equal(app.snapshot().warning, "read");
});

test("des données incompatibles ne sont jamais écrasées avant reset réussi", () => {
  let saves = 0;
  const app = harness({ load: () => ({ ok: false, kind: "incompatible" }), save: () => { saves += 1; return { ok: true }; } });
  app.initialize(); app.add({ title: "Session", author: "Mémoire" }); app.retry();
  assert.equal(saves, 0); assert.equal(app.snapshot().warning, "incompatible");
  assert.equal(app.reset().ok, true);
  app.add({ title: "Après", author: "Reset" });
  assert.equal(saves, 1);
});

test("une suppression échouée ne prétend pas réussir ni effacer la mémoire", () => {
  const app = harness({ reset: () => ({ ok: false, kind: "delete" }) }); app.initialize(); app.add({ title: "A", author: "B" });
  assert.equal(app.reset().ok, false); assert.equal(app.snapshot().books.length, 1); assert.equal(app.snapshot().warning, "delete");
});

test("une réinitialisation réussie revient à l’état vide", () => {
  const app = harness(); app.initialize(); app.add({ title: "A", author: "B" });
  assert.deepEqual(app.reset(), { ok: true, state: { books: [], filter: "all", warning: null, incompatible: false } });
});
