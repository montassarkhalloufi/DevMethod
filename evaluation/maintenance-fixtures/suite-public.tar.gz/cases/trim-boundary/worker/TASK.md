# Fix a localized title validation regression

An intentionally injected fixture defect in src/domain.mjs checks untrimmed input length before applying the existing trim-then-validate rule. Restore the existing rule: leading/trailing whitespace does not consume the 120-unit title allowance, but the resulting trimmed title must contain 1..120 JavaScript string code units. Keep invalid types and blank titles rejected.

This is a local correction inside the existing domain boundary, not a new product/design/architecture decision. Preserve all unrelated files and rules. Add a focused regression that fails on the starting defect and run the relevant check; report the result without launching the historical global project stages.
