(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.LisiereDomain = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const STATUSES = Object.freeze(["planned", "reading", "done"]);
  const FILTERS = Object.freeze(["all", ...STATUSES]);
  const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  const REFERENCE_COVERS = Object.freeze({
    "les jours tranquilles\u0000élise martin": "jours",
    "atlas des chemins\u0000noé larden": "atlas",
    "la maison des marées\u0000clara duvall": "marees"
  });

  function codePointLength(value) {
    return Array.from(value).length;
  }

  function normalizeField(value) {
    if (typeof value !== "string") return { ok: false, error: "required" };
    const normalized = value.trim();
    if (!normalized) return { ok: false, error: "required" };
    if (codePointLength(normalized) > 120) return { ok: false, error: "too-long" };
    return { ok: true, value: normalized };
  }

  function validateBook(book) {
    if (!book || typeof book !== "object" || Array.isArray(book)) return false;
    if (!UUID.test(book.id) || !STATUSES.includes(book.status)) return false;
    const title = normalizeField(book.title);
    const author = normalizeField(book.author);
    return title.ok && author.ok && title.value === book.title && author.value === book.author;
  }

  function createBook(input, idFactory) {
    const title = normalizeField(input && input.title);
    const author = normalizeField(input && input.author);
    const errors = {};
    if (!title.ok) errors.title = title.error;
    if (!author.ok) errors.author = author.error;
    if (Object.keys(errors).length) return { ok: false, errors };
    let id;
    try { id = idFactory(); }
    catch (_) { return { ok: false, errors: { form: "id-unavailable" } }; }
    if (!UUID.test(id)) return { ok: false, errors: { form: "invalid-id" } };
    return { ok: true, book: { id, title: title.value, author: author.value, status: "planned" } };
  }

  function nextStatus(status) {
    if (status === "planned") return "reading";
    if (status === "reading") return "done";
    if (status === "done") return "reading";
    return null;
  }

  function transitionBook(book) {
    if (!validateBook(book)) return { ok: false, error: "invalid-book" };
    const status = nextStatus(book.status);
    if (!status) return { ok: false, error: "invalid-transition" };
    return { ok: true, book: { ...book, status } };
  }

  function filterBooks(books, filter) {
    if (!FILTERS.includes(filter)) return { ok: false, error: "invalid-filter" };
    return { ok: true, books: filter === "all" ? books.slice() : books.filter((book) => book.status === filter) };
  }

  function coverSeed(book) {
    const source = `${book.id}|${book.title}|${book.author}`;
    let hash = 2166136261;
    for (const character of source) {
      hash ^= character.codePointAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return hash >>> 0;
  }

  function referenceCover(book) {
    if (!book || typeof book.title !== "string" || typeof book.author !== "string") return null;
    return REFERENCE_COVERS[`${book.title.toLocaleLowerCase("fr")}\u0000${book.author.toLocaleLowerCase("fr")}`] || null;
  }

  function createUuid(cryptoPort, random = Math.random) {
    if (cryptoPort && typeof cryptoPort.randomUUID === "function") return cryptoPort.randomUUID();
    const bytes = new Uint8Array(16);
    if (cryptoPort && typeof cryptoPort.getRandomValues === "function") cryptoPort.getRandomValues(bytes);
    else for (let index = 0; index < bytes.length; index += 1) bytes[index] = Math.floor(random() * 256);
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, (value) => value.toString(16).padStart(2, "0"));
    return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
  }

  return { STATUSES, FILTERS, codePointLength, normalizeField, validateBook, createBook, nextStatus, transitionBook, filterBooks, coverSeed, referenceCover, createUuid };
});
