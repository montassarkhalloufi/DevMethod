# Independent maintenance fixture package

Start with manifest.json and PROTOCOL.md. Three public cases use existing Pocket Tasks code at the pinned revision. No native trial has been run.

Coordinator-only setup:

```sh
node setup.mjs resume-filter /new/absolute/worker-root
node evaluator/evaluate.mjs resume-filter /absolute/candidate-root
```

The evaluator prints criterion verdicts plus manual-review requirements. Exit 0 means automatic checks passed, 1 means observed assertion failure, 2 means a technical/unclassified problem. The coordinator must retain raw invocation data when a fatal import or execution error prevents JSON output.

The worker sees only its copied workspace and its prompt. Do not reveal evaluator/, controls/ or reserved-transfer/. Do not flatten the initial Git tree into a new commit. Existing tests are baseline product tests; the worker authors its new relevant regression. Captured evidence must retain source scope, command and actual outcomes.

After a worker returns, select its actually authored/meaningfully extended test files from the diff. This does not authorize any native call:

```sh
node evaluator/assess-agent-tests.mjs resume-filter /absolute/candidate-root tests/worker-regression.test.mjs
```

A healthy-reference failure makes mutation comparison unavailable; inspect why rather than claiming the tests are weak. Manual verdicts and browser fidelity remain outside this local executable check. The reserved transfer is intentionally not described here; keep it unavailable to any correction author until the proposed candidate is frozen.
