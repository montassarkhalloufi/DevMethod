# Supplied independent prior observation

The fixture author actually executed six pure-domain assertions. The raw invocation, exit and source/checker hashes are in domain-baseline.json. This is supplied evidence, not your own execution and not a filter-persistence test. The checker is independently owned outside your workspace. Evaluate relevance and source pins before reuse. A historical pass cannot validate changed inputs.
