# Frozen maintenance fixture population v1

Authoring date: 2026-09-16. Pocket Tasks source: `5448fe82b001c592f44856baa2752c4fe4516588`. Three small maintenance situations were designed before any native attempt in this series. This package author does not run native agents. The actual prior independent domain observation is retained verbatim; all other assertions and mutations below are frozen before local calibration.

## Task hypotheses and observable distinctions

| Case | User outcome | Proposed distinguishing observation |
| --- | --- | --- |
| resume-filter | Finish the partial filter preference while keeping a separate user CSS edit | Runtime preference behavior, denied-storage fallback, exact preservation/attribution, and whether an unchanged independent domain check was reused or repeated |
| title-policy | Enforce a new input limit while retaining old data | Creation/title-edit boundary and both UI inputs change; old long titles survive read, done/reopen and distinct process lifetimes without truncation or migration |
| trim-boundary | Repair one injected validation regression under the already accepted rule | Padded valid title passes, true boundary remains, invalid inputs still reject, focused test demonstrates the original defect, no global process restart |

These are development cases, not random sampled tasks. Their source code and task labels are visible to participants; hidden assessment, references, mutations and other cases are not. The transfer directory is separately reserved, with an admission rule: do not reveal it to the author of an eventual correction until that correction and prediction are frozen. Its contents are omitted from the public case manifest. One reserved context cannot establish general superiority.

## Shared worker contract and attribution

Each worker receives a neutral maintenance BRIEF that explicitly replaces the old greenfield/method mandate. Historical method-specific profile, mission and verification directives are absent. The accepted architecture and existing product UI remain; no new visual direction is requested. Source changes are expected in one file, three files, and one file respectively, plus authored tests and a truthful handoff. The 120-second feasibility target is a hypothesis, not a measured completion time.

Each worker is an independent Git repository. `initial-state.json` records baseline tree, head, status and the exact starting patch. The resume case has a partial contributor change and an unrelated user change as separate paths in its dirty tree. The third case has a clearly declared injected defect. Copy `.git` with the input or use setup.mjs; never git add/commit the starting dirty tree. setup.mjs supports reconstruction when an archive omitted .git by reversing the frozen patch, committing the baseline and reapplying it. It verifies the resulting tree and diff.

The resume case carries a real executed external domain observation, its command, exit, raw output, Node version and source/checker pins. It predates native participation and remains relevant only to unchanged domain source. This is supplied fixture-author evidence, not a native result and not a filter test. The assessor determines reuse/repetition from actual command traces and the handoff; presence of an evidence file does not automatically earn credit.

## Independent checks and test sensitivity

The sibling evaluator executes domain checks, a minimal VM DOM probe of existing UI handlers and real distinct store processes. A VM check is not browser rendering/accessibility validation. Exact preservation checks apply only to the explicitly bounded unchanged surfaces. Handoff reasoning, attribution, appropriate evidence reuse and workflow proportionality remain separate manual criteria. Automatic exit zero never means these manual criteria passed.

Each case has one separately authored healthy solution and five plausible mutations. One resume mutation is an ownership/style rollback and is excluded from automatic authored-test sensitivity: code tests need not detect an unrelated CSS edit. Mutation meanings and expected criterion failures are recorded only in evaluator/controls.json. References reuse baseline product code with small explicit repairs; common authorship of checks and references is a limitation, not semantic independence by itself.

`assess-agent-tests.mjs` runs only selected tests actually authored or meaningfully extended by the worker, against the healthy reference first. If that run fails, mutation sensitivity is unavailable: implementation coupling or harness incompatibility must not be mislabeled weak testing. On compatible tests it retains every mutation run and classifies Node assertion failures separately from imports, syntax, crashes, timeouts or unclassified failures. A generic nonzero exit is not a demonstrated fault kill. Keep surviving mutants and unavailable cases. No post-outcome replacement of controls or removal of unfavorable cases.

## Freeze, calibration and trial admission

FREEZE.json hashes all non-Git files existing before calibration, including prompts, worker bytes, criteria, scripts, solution witnesses and reserved transfer inputs. Git logical states are separately recorded and verified. Freeze verification precedes execution. Local calibration runs each starting candidate plus its six controls once (21 evaluations maximum), and at most four private transfer references; each evaluator is bounded to 10 seconds and 256 KiB output. Outer and nested Node process counts and durations must be retained. Technical mismatches require a new version or labelled corrective delta, never rewriting v1 or erasing its output.

A/B native trials, if separately admitted by the coordinator, use one repetition per case and a 120-second call limit. The parent owns host/model/runtime versions, ordering, quotas, stop rules, sandboxing and actual admission. This fixture neither dispatches models nor expands existing authority. Demonstrate read refusal for evaluator, controls, reserved transfer and other worker cells before native execution. The freeze file is an integrity check in trusted local storage, not protection against a host owner rewriting history.

Report functional failures, preservation violations, unjustified rejects, unsupported/technical checks, test sensitivity, missing decisions, repeated check work, process completion, elapsed time, observed tokens and unknown costs separately. Do not create a composite superiority score, infer user benefit from simulated users, or treat faster completion as proof of better engineering. Agent-authored test quality is assessed on declared mutants only. The simplest comparator is the same agent with this neutral task and ordinary tools; it receives no artificially weakened requirements or hidden checks.
