import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';

export async function openUI(root, { storage = new Map(), denied = false, tasks } = {}) {
  const all = [];
  const nodes = new Map();
  const preferences = ['all', 'active', 'completed'];
  function element(tag = 'div') {
    const node = { tag, textContent: '', value: '', hidden: false, disabled: false, dataset: {}, children: [], attributes: {}, listeners: new Map(),
      setAttribute(key, value) { this.attributes[key] = value; },
      addEventListener(type, fn) { this.listeners.set(type, fn); },
      replaceChildren(...items) { this.children = items; },
      append(...items) { this.children.push(...items); },
      focus() { this.focused = true; },
    };
    all.push(node); return node;
  }
  for (const id of ['status', 'error', 'retry', 'tasks', 'empty', 'count', 'add-form', 'new-title']) {
    const node = element(id === 'new-title' ? 'input' : 'div'); node.id = id; nodes.set(`#${id}`, node);
  }
  const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
  const input = html.match(/<input\b[^>]*\bid=["']new-title["'][^>]*>/)?.[0];
  nodes.get('#new-title').maxLength = Number(input?.match(/maxlength=["'](\d+)["']/)?.[1] ?? -1);
  const filters = preferences.map((filter) => { const node = element('button'); node.dataset.filter = filter; return node; });
  const selected = () => filters.filter((node) => node.attributes['aria-pressed'] === 'true').map((node) => node.dataset.filter);
  const document = {
    querySelector(selector) {
      if (nodes.has(selector)) return nodes.get(selector);
      if (selector.startsWith('#')) return all.findLast((node) => node.id === selector.slice(1)) ?? null;
      const attribute = selector.match(/^\[data-(toggle|edit)="([^"]+)"\]$/);
      return attribute ? all.findLast((node) => node.dataset[attribute[1]] === attribute[2]) ?? null : null;
    },
    querySelectorAll(selector) {
      if (selector === '[data-filter]') return filters;
      if (selector === '[data-toggle]') return all.filter((node) => node.dataset.toggle);
      if (selector === 'button,input') return all.filter((node) => ['button', 'input'].includes(node.tag));
      return [];
    },
    createElement: element,
  };
  const context = vm.createContext({ document, console, setTimeout, clearTimeout,
    localStorage: {
      getItem(key) { if (denied) throw new Error('Storage disabled'); return storage.get(key) ?? null; },
      setItem(key, value) { if (denied) throw new Error('Storage disabled'); storage.set(key, String(value)); },
    },
    fetch: async () => ({ status: 200, ok: true, json: async () => ({ tasks: tasks ?? [
      { id: 'open', title: 'Open task', done: false }, { id: 'done', title: 'Done task', done: true },
    ] }) }),
  });
  context.window = context;
  assert.doesNotThrow(() => vm.runInContext(fs.readFileSync(path.join(root, 'public/app.js'), 'utf8'), context, { timeout: 1000 }), 'Existing UI must initialize even when preference storage is unavailable');
  const settle = () => new Promise((resolve) => setImmediate(resolve));
  await settle();
  return { nodes, selected, storage, document, all,
    async clickFilter(value) { const listener = filters.find((node) => node.dataset.filter === value).listeners.get('click'); assert.equal(typeof listener, 'function'); assert.doesNotThrow(() => listener()); await settle(); },
    async edit(id) { const button = all.findLast((node) => node.dataset.edit === id); assert.ok(button, 'An edit control must exist'); assert.doesNotThrow(() => button.listeners.get('click')()); await settle(); return document.querySelector('#edit-title'); },
  };
}
