import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
const suite = path.dirname(fileURLToPath(import.meta.url));
const [id, destination] = process.argv.slice(2);
const manifest = JSON.parse(fs.readFileSync(path.join(suite, 'manifest.json')));
const entry = manifest.cases.find((item) => item.id === id);
if (!entry || !path.isAbsolute(destination) || fs.existsSync(destination)) throw new Error('Use a known case and a new absolute destination');
const frozen = JSON.parse(fs.readFileSync(path.join(suite, 'FREEZE.json')));
const source = path.join(suite, entry.directory);
for (const [file, expected] of Object.entries(frozen.files)) {
  if (!file.startsWith(entry.directory + '/')) continue;
  const bytes = fs.readFileSync(path.join(suite, file));
  if (createHash('sha256').update(bytes).digest('hex') !== expected) throw new Error('Frozen worker changed: ' + file);
}
fs.cpSync(source, destination, { recursive: true });
const state = JSON.parse(fs.readFileSync(path.join(suite, entry.initialState)));
if (!fs.existsSync(path.join(destination, '.git'))) {
  if (state.diff) execFileSync('git', ['apply', '--reverse', '-'], { cwd: destination, input: state.diff });
  execFileSync('git', ['init', '-q'], { cwd: destination });
  execFileSync('git', ['add', '.'], { cwd: destination });
  execFileSync('git', ['-c', 'user.name=Fixture Author', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'Reconstructed neutral maintenance baseline'], { cwd: destination });
  if (state.diff) execFileSync('git', ['apply', '-'], { cwd: destination, input: state.diff });
}
const git = (...args) => execFileSync('git', args, { cwd: destination, encoding: 'utf8' }).trimEnd();
if (git('rev-parse', 'HEAD^{tree}') !== state.baseTree || git('diff') !== state.diff.trimEnd() || git('status', '--short') !== state.status.trimEnd()) throw new Error('Starting attribution differs from the frozen baseline');
console.log(JSON.stringify({ case: id, destination, baselineTree: state.baseTree, priorChangesPreserved: true }));
