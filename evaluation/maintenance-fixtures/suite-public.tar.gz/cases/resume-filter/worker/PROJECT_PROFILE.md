# Existing application context

Pocket Tasks is already implemented. Read BRIEF.md for continuing invariants and TASK.md for the only current request. Source provenance: examples/pocket-tasks at 5448fe82b001c592f44856baa2752c4fe4516588. The historical greenfield records have been replaced for this maintenance fixture, not silently carried into its experimental conditions.

Entry points: src/domain.mjs (pure validation), src/store.mjs (serialized atomic file replacement), server.mjs (HTTP/local boundary), public/ (existing interface). Node built-ins only. Run npm test for the existing suite; HTTP tests require local ephemeral loopback access. Choose targeted checks proportionate to your change.
