# Pocket Tasks maintenance workspace

Existing fictional local application. See BRIEF.md and TASK.md. Start with `npm start`; use PORT and DATA_FILE to select an isolated local instance. No dependency installation is needed. Tests run with `npm test`; local HTTP tests need loopback access.
