import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
const suite = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const [caseId, candidate, ...tests] = process.argv.slice(2);
const controls = JSON.parse(fs.readFileSync(path.join(suite, 'evaluator/controls.json')))[caseId];
if (!controls || !candidate || tests.length < 1 || tests.length > 8 || tests.some((file) => !/^tests\/(?:[a-zA-Z0-9_-]+\/)*[a-zA-Z0-9_.-]+\.test\.mjs$/.test(file))) throw new Error('Supply a case, candidate root and 1..8 authored test paths under tests/');
const workspace = fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()), 'maintenance-agent-test-sensitivity-'));
const report = { format: 1, kind: 'authored-test-sensitivity-to-known-controlled-faults', case: caseId, tests, workspace, results: [], limits: 'At most six local test runner processes, ten seconds and 256 KiB each. No native/model calls. Hidden witnesses are compatibility probes, not held-out product samples.' };
const save = () => fs.writeFileSync(path.join(workspace, 'results.json'), JSON.stringify(report, null, 2) + '\n');
const variants = [['healthy', controls.healthy], ...Object.entries(controls.mutants).filter(([, mutation]) => mutation.testSensitivity !== false).map(([name, mutation]) => [name, mutation.directory])];
for (const [name, directory] of variants) {
  const root = path.join(workspace, name); fs.cpSync(path.join(suite, directory), root, { recursive: true });
  for (const test of tests) {
    const original = path.resolve(candidate, test);
    if (!fs.lstatSync(original).isFile()) throw new Error('Expected an ordinary authored test file');
    fs.mkdirSync(path.dirname(path.join(root, test)), { recursive: true }); fs.copyFileSync(original, path.join(root, test));
  }
  const start = performance.now();
  const child = spawnSync(process.execPath, ['--test', '--test-reporter=tap', ...tests], { cwd: root, encoding: 'utf8', timeout: 10000, maxBuffer: 262144 });
  const assertions = (child.stdout ?? '').match(/code: ['"]ERR_ASSERTION['"]/g)?.length ?? 0;
  const unavailable = !!child.error || !!child.signal || /ERR_MODULE_NOT_FOUND|ERR_TEST_FAILURE.*cancelled|SyntaxError:|ReferenceError:/.test((child.stdout ?? '') + (child.stderr ?? ''));
  const observation = { variant: name, status: child.status, signal: child.signal, error: child.error?.message ?? null, stdout: child.stdout, stderr: child.stderr, durationMs: performance.now() - start, classification: unavailable ? 'execution-unavailable' : child.status === 0 ? 'passed' : child.status === 1 && assertions > 0 ? 'assertion-failed' : 'unclassified-failure' };
  report.results.push(observation); save();
  if (name === 'healthy' && observation.classification !== 'passed') { report.comparable = false; report.reason = 'Tests do not pass the independent healthy witness; no mutant kill score is valid. This may be implementation coupling or a checker compatibility problem, not proof of weak tests.'; break; }
  report.comparable = true;
}
report.assertedFaultDetections = report.comparable ? report.results.filter((item) => item.variant !== 'healthy' && item.classification === 'assertion-failed').map((item) => item.variant) : null;
report.unavailable = report.results.filter((item) => ['execution-unavailable', 'unclassified-failure'].includes(item.classification)).map((item) => item.variant);
save(); console.log(JSON.stringify({ workspace, comparable: report.comparable, assertedFaultDetections: report.assertedFaultDetections, unavailable: report.unavailable }));
