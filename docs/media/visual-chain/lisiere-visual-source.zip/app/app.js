import { addBook, filterBooks, nextStatus, parseBooks } from './domain.mjs';

const STORAGE_KEY = 'lisiere.books.v1';
const labels = {
  planned: { status: 'À lire', action: 'Commencer' },
  reading: { status: 'En cours', action: 'Marquer terminé' },
  done: { status: 'Terminé', action: 'Rouvrir' }
};

const elements = {
  library: document.querySelector('#library'), empty: document.querySelector('#empty'),
  filters: [...document.querySelectorAll('[data-filter]')], dialog: document.querySelector('#add-dialog'),
  form: document.querySelector('#add-form'), title: document.querySelector('#title'),
  alert: document.querySelector('#storage-alert')
};

let stored;
try { stored = localStorage.getItem(STORAGE_KEY); } catch { stored = '{storage-unavailable'; }
const loaded = parseBooks(stored);
let books = loaded.books;
let filter = 'all';
let storageLocked = Boolean(loaded.error);
elements.alert.hidden = !storageLocked;

function persist() {
  if (storageLocked) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
  } catch {
    storageLocked = true;
    elements.alert.hidden = false;
  }
}

function render() {
  const visible = filterBooks(books, filter);
  elements.library.replaceChildren(...visible.map(book => {
    const article = document.createElement('article');
    article.className = 'book';
    const cover = document.createElement('div');
    cover.className = `cover ${book.cover || 'cover-plain'}`;
    cover.setAttribute('role', 'img');
    cover.setAttribute('aria-label', `Couverture de ${book.title}`);
    const details = document.createElement('div');
    details.className = 'book-details';
    const title = document.createElement('h2');
    title.textContent = book.title;
    const author = document.createElement('p');
    author.textContent = book.author;
    const status = document.createElement('span');
    status.className = `status ${book.status}`;
    status.textContent = labels[book.status].status;
    const action = document.createElement('button');
    action.className = 'book-action';
    action.type = 'button';
    action.dataset.bookId = book.id;
    action.textContent = labels[book.status].action;
    action.addEventListener('click', () => {
      books = books.map(candidate => candidate.id === book.id ? { ...candidate, status: nextStatus(candidate.status) } : candidate);
      persist();
      render();
      const next = [...elements.library.querySelectorAll('button')].find(button => button.dataset.bookId === book.id);
      (next || elements.filters.find(button => button.dataset.filter === filter))?.focus();
    });
    details.append(title, author, status, action);
    article.append(cover, details);
    return article;
  }));
  elements.empty.hidden = visible.length !== 0;
}

elements.filters.forEach(button => button.addEventListener('click', () => {
  filter = button.dataset.filter;
  elements.filters.forEach(candidate => candidate.setAttribute('aria-pressed', String(candidate === button)));
  render();
}));

function closeDialog() { elements.dialog.close(); }
document.querySelector('#open-dialog').addEventListener('click', () => elements.dialog.showModal());
document.querySelector('#close-dialog').addEventListener('click', closeDialog);
document.querySelector('#cancel-dialog').addEventListener('click', closeDialog);
elements.dialog.addEventListener('click', event => {
  if (event.target === elements.dialog) closeDialog();
});
elements.form.addEventListener('submit', event => {
  event.preventDefault();
  if (!elements.form.reportValidity()) return;
  const data = new FormData(elements.form);
  books = addBook(books, String(data.get('title')), String(data.get('author')));
  persist();
  elements.form.reset();
  closeDialog();
  filter = 'all';
  elements.filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.filter === filter)));
  render();
});

document.querySelector('#reset-storage').addEventListener('click', () => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(books));
    storageLocked = false;
    elements.alert.hidden = true;
  } catch { elements.alert.hidden = false; }
});

render();
