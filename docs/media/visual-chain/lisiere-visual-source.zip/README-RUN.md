# Lisière — prototype visuel

Depuis la racine extraite : `python3 -m http.server 8768`, puis ouvrir http://localhost:8768/app/. Tests : `node --test tests/*.mjs`.

Le master et les images dérivées précèdent cette réalisation ; les captures et limites sont documentées dans la démonstration.
