export const INITIAL_BOOKS = Object.freeze([
  { id: 'jours-tranquilles', title: 'Les jours tranquilles', author: 'Élise Martin', status: 'reading', cover: 'cover-days' },
  { id: 'atlas-chemins', title: 'Atlas des chemins', author: 'Noé Larden', status: 'planned', cover: 'cover-atlas' },
  { id: 'maison-marees', title: 'La maison des marées', author: 'Clara Duvall', status: 'reading', cover: 'cover-tides' }
]);

export const VALID_STATUSES = ['planned', 'reading', 'done'];

export function isBook(value) {
  return Boolean(value && typeof value.id === 'string' && typeof value.title === 'string' && value.title.trim() &&
    typeof value.author === 'string' && value.author.trim() && VALID_STATUSES.includes(value.status));
}

export function parseBooks(raw) {
  if (raw === null) return { books: INITIAL_BOOKS.map(book => ({ ...book })), error: null };
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || !parsed.every(isBook)) throw new Error('Format invalide');
    return { books: parsed, error: null };
  } catch {
    return { books: INITIAL_BOOKS.map(book => ({ ...book })), error: 'invalid-storage' };
  }
}

export function filterBooks(books, filter) {
  return filter === 'all' ? books : books.filter(book => book.status === filter);
}

export function nextStatus(status) {
  if (status === 'planned') return 'reading';
  if (status === 'reading') return 'done';
  return 'reading';
}

export function addBook(books, title, author, id = `book-${Date.now()}`) {
  const cleanTitle = title.trim();
  const cleanAuthor = author.trim();
  if (!cleanTitle || !cleanAuthor) return books;
  return [...books, { id, title: cleanTitle, author: cleanAuthor, status: 'planned', cover: 'cover-plain' }];
}
