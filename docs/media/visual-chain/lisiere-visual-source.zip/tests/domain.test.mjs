import test from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_BOOKS, addBook, filterBooks, nextStatus, parseBooks } from '../app/domain.mjs';

test('charge les fixtures si aucun stockage n’existe', () => {
  const result = parseBooks(null);
  assert.equal(result.error, null);
  assert.equal(result.books.length, 3);
  assert.notEqual(result.books, INITIAL_BOOKS);
});

test('signale une donnée illisible sans la transformer', () => {
  const result = parseBooks('{cassé');
  assert.equal(result.error, 'invalid-storage');
  assert.equal(result.books.length, 3);
});

test('rejette un tableau dont le contrat est incomplet', () => {
  assert.equal(parseBooks('[{"title":"Sans auteur"}]').error, 'invalid-storage');
});

test('filtre les livres par état', () => {
  assert.deepEqual(filterBooks(INITIAL_BOOKS, 'planned').map(book => book.id), ['atlas-chemins']);
  assert.equal(filterBooks(INITIAL_BOOKS, 'all').length, 3);
});

test('enchaîne commencer, terminer et rouvrir', () => {
  assert.equal(nextStatus('planned'), 'reading');
  assert.equal(nextStatus('reading'), 'done');
  assert.equal(nextStatus('done'), 'reading');
});

test('ajoute un livre planifié en normalisant les champs', () => {
  const books = addBook([], '  Les heures claires ', ' Camille Laurent ', 'nouveau');
  assert.deepEqual(books[0], { id: 'nouveau', title: 'Les heures claires', author: 'Camille Laurent', status: 'planned', cover: 'cover-plain' });
  assert.equal(addBook(books, ' ', 'Auteur').length, 1);
});
