# Votre projet local

Node.js 22+ suffit. Lancez `node launch.mjs 4399`, puis ouvrez http://127.0.0.1:4399/.

Le code est dans revisions/, les décisions et demandes dans .devmethod/studio.json, les données actuelles dans .devmethod/data.json, les références dans references/. Ce runtime local n’a ni authentification ni déploiement public. Aucun accès fournisseur ou secret n’est exporté.

Pour reprendre dans DevMethod : `devmethod studio --workspace /chemin/absolu/vers/ce/dossier`. Revenir à une version de code ne restaure pas d’anciennes données. Les changements de schéma restent à vérifier.
