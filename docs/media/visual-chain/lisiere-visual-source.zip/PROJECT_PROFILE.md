# Project profile

Complete from source material during first startup; keep unknowns explicit. This profile is a template, not an already accepted decision.

- Project / alias:
- User objective and success criterion:
- Phase / authorized scope / exclusions:
- Foundational constraints: operator time, fixed budget, variable cost, deadline.
- Product source and accepted decisions (links + date/version):
- Ticket source / readiness criteria:
- Canonical mission / plan / evidence locations (reuse existing conventions; links only, no copied status):
- Approved UI reference (screen, version, viewport, states):
- Canonical code (repository, branch, inspected commit):
- Effective stack (runtime, frameworks, package manager, lockfile versions):
- Domain / boundaries / owned data:
- Local commands actually available:
- Critical journeys / risks to verify:
- Personal data, purposes, approved retention:
- Integrations and contracts; do not enter any secret value:
- Rendering by surface: public static/ISR/SSR, interactive, private; as needed.
- Applicable CI policy, budget, and authorizations:
- Required skills + local path + provenance:
- External actions already authorized in this session and limits:
- Reversible assumptions / decisions to resolve:
- Next independent slice:

Session authorizations do not become permanent authorizations for every session.
