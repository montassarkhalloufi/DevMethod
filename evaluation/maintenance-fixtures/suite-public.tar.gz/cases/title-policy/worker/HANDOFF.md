# Maintenance starting point

The existing product is the starting point. No work for the current request has been claimed complete. Read TASK.md and the actual files; update this handoff after relevant verification.
