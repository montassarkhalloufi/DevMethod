(function (root, factory) {
  const api = factory(root.LisiereDomain);
  if (typeof module === "object" && module.exports) module.exports = factory(require("./domain.js"));
  root.LisiereStorage = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (Domain) {
  "use strict";
  const KEY = "lisiere.library";

  function create(port) {
    function load() {
      let raw;
      try { raw = port.getItem(KEY); }
      catch (cause) { return { ok: false, kind: "read", cause }; }
      if (raw === null) return { ok: true, books: [] };
      let data;
      try { data = JSON.parse(raw); }
      catch (cause) { return { ok: false, kind: "incompatible", cause }; }
      if (!data || typeof data !== "object" || Array.isArray(data) || data.version !== 1 || !Array.isArray(data.books)) {
        return { ok: false, kind: "incompatible" };
      }
      const ids = new Set();
      for (const book of data.books) {
        if (!Domain.validateBook(book) || ids.has(book.id)) return { ok: false, kind: "incompatible" };
        ids.add(book.id);
      }
      return { ok: true, books: data.books.map((book) => ({ ...book })) };
    }

    function save(books) {
      try {
        port.setItem(KEY, JSON.stringify({ version: 1, books }));
        return { ok: true };
      } catch (cause) { return { ok: false, kind: "write", cause }; }
    }

    function reset() {
      try { port.removeItem(KEY); return { ok: true }; }
      catch (cause) { return { ok: false, kind: "delete", cause }; }
    }

    return { load, save, reset };
  }
  function fromBrowser(browser) {
    let port;
    try { port = browser.localStorage; }
    catch (error) {
      port = {
        getItem() { throw error; },
        setItem() { throw error; },
        removeItem() { throw error; }
      };
    }
    return create(port);
  }
  return { KEY, create, fromBrowser };
});
