# Chrome evidence — parent, 2026-09-13

Executed with installed Playwright and Chrome, local HTTP app, after correction 08b. Check scripts: ../check.cjs and ../extra-check.cjs. These are actual parent observations, not CLI claims of browser execution.

Passed: empty library; add three fictional books via form; filter to empty category and return all; start/finish/reopen; reload retains three books and states; required field feedback; Escape closes dialog; mobile390x844 no horizontal overflow. Desktop1440x1000 normal journey had zero page errors.

Regression evidence: localStorage getter throwing SecurityError produces visible warning and zero uncaught errors. Malformed storage remains the identical string after an in-memory add. A120-code-point emoji title is accepted. Disabling crypto.randomUUID still allows adding a book through fallback.

Screenshots ../browser-desktop.png and ../browser-mobile.png visually inspected. Approved cover art now matches the three title/author pairs. Composition, ivory/rust palette, filters, horizontal desktop cards and mobile rows preserved. Remaining differences: Georgia is bolder than the generated type, spacing and cover sizes adapt to viewport, mobile buttons are larger for use. No claim of pixel identity, automated perceptual metric or full accessibility/cross-browser audit. Reference fidelity assessed by the parent assistant, not a separate human panel.

No remote requests or paid application provider calls. Prototype delivered locally, not deployed. Initial preliminary failure documented in BROWSER-PRELIMINARY.md is superseded by passing getter regression.

## Additional requested controls
Parent executed accessibility-check.cjs after initial verify. Entire route using Tab/Shift+Tab/Enter only: brand → open dialog → title → author → submit → start → finish → reopen → filter planned; all passed. Contrast ratios from CSS color values: ink/ivory16.05, muted/ivory5.79, white/rust6.93, rust/ivory6.15, focus/ivory6.43. All above4.5. This measures those selected pairs, not every rendered pixel.
Reflow at720 CSS pixels (half1440) and320 CSS pixels passes no horizontal page overflow. This is viewport emulation; native Chrome browser zoom200% was not operated and remains unverified. Do not mislabel this as native zoom. Other browsers/full accessibility remain outside the observed evidence. These limits are disclosed for the local prototype, no universal claim requested.
