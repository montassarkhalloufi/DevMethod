# VISUAL-1 — Lisière, livraison locale

Objectif : bibliothèque personnelle française, trois écrans/états cohérents avec le master : bibliothèque, ajout et lectures terminées. HTML/CSS/JS sans dépendance ni serveur applicatif. Stockage local ; aucun déploiement.

Référence approuvée : references/master.png, direction A sélectionnée et master approuvé dans la session préparatoire. Les deux images add-book-v1.png et completed-v1.png ont été générées avec le master comme entrée AVANT cette nouvelle implémentation. Elles déclinent les comportements déjà prévus. Aucune nouvelle approbation utilisateur distincte n'est revendiquée.

Code : app/. Contrats/logique : app/domain.mjs. Critères : ajouter titre/auteur, filtrer, commencer/terminer/rouvrir, persister, préserver le stockage illisible, dialogue clavier, mobile.

Preuves locales après relecture : 6 tests Node réussis ; Chrome confirme les actions, focus après transition, état vide, sauvegarde/rechargement, mobile390px et non-écrasement du stockage invalide. Captures dans la démonstration. Corrections parent : [hidden] masqué et focus conservé après render. Limites : revue supervisée, police système, pas d'identité pixel ou audit complet tous navigateurs.

Statut : réalisé et vérifié localement. Aucun service publié. Le parent a consigné ce checkpoint après le test : l'exécution CLI initiale avait produit le code/tests mais omis le document de mission demandé. Ce constat est conservé, pas présenté comme un suivi autonome parfait.

Commandes : node --test tests/*.mjs ; python3 -m http.server 8768 puis /app/.
Reprise : $project-foundation status VISUAL-1. Aucun nouveau périmètre autorisé automatiquement.
