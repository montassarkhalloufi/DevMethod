const test = require("node:test");
const assert = require("node:assert/strict");
const Storage = require("../app/storage.js");
const ID = "123e4567-e89b-42d3-a456-426614174000";
const book = { id: ID, title: "Titre", author: "Auteur", status: "planned" };

function fake(initial = null) {
  let value = initial;
  return { getItem: () => value, setItem: (_, next) => { value = next; }, removeItem: () => { value = null; }, value: () => value };
}

test("une clé absente charge une bibliothèque vide", () => assert.deepEqual(Storage.create(fake()).load(), { ok: true, books: [] }));

test("enregistre et recharge l’enveloppe v1", () => {
  const port = fake(); const store = Storage.create(port);
  assert.deepEqual(store.save([book]), { ok: true });
  assert.deepEqual(JSON.parse(port.value()), { version: 1, books: [book] });
  assert.deepEqual(store.load(), { ok: true, books: [book] });
});

for (const [name, value] of [
  ["JSON illisible", "{"], ["schéma invalide", JSON.stringify({ version: 1, books: {} })],
  ["version inconnue", JSON.stringify({ version: 2, books: [] })],
  ["livre invalide", JSON.stringify({ version: 1, books: [{ ...book, status: "lost" }] })],
  ["identifiant dupliqué", JSON.stringify({ version: 1, books: [book, { ...book, title: "Autre" }] })]
]) test(name, () => assert.equal(Storage.create(fake(value)).load().kind, "incompatible"));

test("traduit les exceptions de lecture, écriture et suppression", () => {
  assert.equal(Storage.create({ getItem() { throw Error("no"); } }).load().kind, "read");
  assert.equal(Storage.create({ setItem() { throw Error("no"); } }).save([]).kind, "write");
  assert.equal(Storage.create({ removeItem() { throw Error("no"); } }).reset().kind, "delete");
});

test("capture un getter localStorage qui lève avant toute lecture", () => {
  const browser = {};
  Object.defineProperty(browser, "localStorage", { get() { throw new Error("blocked"); } });
  assert.equal(Storage.fromBrowser(browser).load().kind, "read");
});

test("ne supprime que la clé possédée", () => {
  let removed; const store = Storage.create({ removeItem(key) { removed = key; } });
  assert.equal(store.reset().ok, true); assert.equal(removed, Storage.KEY);
});
