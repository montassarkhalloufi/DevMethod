# Paused contributor note

The filter preference change is partial: a write was added to the click handler, with no restoration or storage error handling yet. The focus-offset CSS edit is the user’s unrelated work. Domain baseline evidence is independently supplied in evidence/; it says nothing about the unfinished filter. Resume from Git diff and TASK.md.
